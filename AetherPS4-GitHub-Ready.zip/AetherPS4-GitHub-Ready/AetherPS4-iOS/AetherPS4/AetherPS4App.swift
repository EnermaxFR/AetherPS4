import SwiftUI

@main
struct AetherPS4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
