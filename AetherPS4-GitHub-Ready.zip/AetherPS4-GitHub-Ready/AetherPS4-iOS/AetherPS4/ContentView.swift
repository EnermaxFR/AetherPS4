import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: "gamecontroller.fill")
                .font(.system(size: 64))
            Text("AetherPS4")
                .font(.largeTitle.bold())
            Text("iOS project structure is ready. The shadPS4 engine still needs to be linked before PS4 emulation can run.")
                .multilineTextAlignment(.center)
                .padding(.horizontal)
        }
    }
}
