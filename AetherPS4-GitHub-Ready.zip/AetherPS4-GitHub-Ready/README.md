# AetherPS4 iOS – GitHub-ready structure

This package adds a real Xcode project and GitHub Actions workflow so the repository can produce an unsigned iOS IPA.

## Important
The active Xcode target is a minimal SwiftUI shell so the CI build can succeed. The previously supplied AetherPS4App.swift and EmulatorProcess.swift are preserved under `AetherPS4-iOS/OriginalSources/`, and `shadps4_ios_api.h` under `Engine/`.

Those original app sources depend on additional Swift types and on the compiled shadPS4 engine/library. They are intentionally not in the active target yet. An IPA produced at this stage is therefore a buildable AetherPS4 shell, not a functioning PS4 emulator.
